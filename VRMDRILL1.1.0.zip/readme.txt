VRMDRILLをダウンロードいただきありがとうございます。

## 概要
あなたのお気に入りのアバターを高速回転させるユニークなアクションゲームです。
揺れもののテストにもご利用いただけます。

## ご注意
激しく回転する、地面を掘るなどの演出が含まれます
アバターのイメージが損なわれてしまうかもしれません
Please be aware that it includes intense spinning and actions such as digging into the ground, which may potentially damage the image of the avatar.

## 操作方法
- **回転**: 画面をクリック

Copyright (c) 2024 hizak